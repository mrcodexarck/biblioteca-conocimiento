import React, { useState, useEffect, useRef } from 'react';
import { auth, db } from '../firebase'; // ✅ Ruta correcta: ../firebase porque estás en src/components
import { doc, getDoc } from 'firebase/firestore';
import Link from '@docusaurus/Link';
import { useHistory } from '@docusaurus/router';

export default function UserMenu() {
  const [user, setUser] = useState(null);
  const [displayName, setDisplayName] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const menuRef = useRef(null);
  const history = useHistory();

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const docRef = doc(db, 'users', currentUser.uid);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            const data = docSnap.data();
            setDisplayName(data.displayName || currentUser.email?.split('@')[0] || 'Usuario');
            setIsAdmin(data.role === 'admin');
          } else {
            setDisplayName(currentUser.email?.split('@')[0] || 'Usuario');
          }
        } catch (error) {
          console.error('Error cargando perfil:', error);
        }
      }
    });

    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      unsubscribe();
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleLogout = async () => {
    await auth.signOut();
    history.push('/');
    window.location.reload();
  };

  // Si no está autenticado, mostrar botón de login
  if (!user) {
    return (
      <Link to="/login" className="button button--primary button--sm">
        Iniciar sesión
      </Link>
    );
  }

  // Si está autenticado, mostrar menú desplegable
  return (
    <div ref={menuRef} style={{ position: 'relative', display: 'inline-block' }}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        style={{
          background: 'transparent',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          padding: '0.4rem 0.8rem',
          borderRadius: '8px',
          fontWeight: 600,
          color: 'var(--ifm-navbar-link-color)',
        }}
        className="user-menu-button"
      >
        <span>👤</span>
        <span>{displayName}</span>
        <span style={{ fontSize: '0.7rem' }}>{isOpen ? '▲' : '▼'}</span>
      </button>

      {isOpen && (
        <div
          style={{
            position: 'absolute',
            top: 'calc(100% + 4px)',
            right: 0,
            background: 'var(--ifm-background-surface-color)',
            border: '1px solid var(--ifm-color-emphasis-300)',
            borderRadius: '10px',
            boxShadow: '0 10px 30px rgba(0,0,0,0.15)',
            minWidth: '220px',
            padding: '0.5rem 0',
            zIndex: 1000,
          }}
          className="user-menu-dropdown"
        >
          <div style={{ padding: '0.5rem 1rem', borderBottom: '1px solid var(--ifm-color-emphasis-200)' }}>
            <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>{displayName}</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--ifm-color-emphasis-600)' }}>
              {isAdmin ? '🔑 Administrador' : '👤 Usuario'}
            </div>
          </div>

          <Link
            to="/perfil"
            style={{
              display: 'block',
              padding: '0.5rem 1rem',
              color: 'var(--ifm-font-color-base)',
              textDecoration: 'none',
              fontSize: '0.9rem',
              transition: 'background 0.15s',
            }}
            onClick={() => setIsOpen(false)}
            onMouseEnter={(e) => e.target.style.background = 'var(--ifm-color-emphasis-100)'}
            onMouseLeave={(e) => e.target.style.background = 'transparent'}
          >
            ⚙️ Mis datos
          </Link>

          <Link
            to="/configuracion"
            style={{
              display: 'block',
              padding: '0.5rem 1rem',
              color: 'var(--ifm-font-color-base)',
              textDecoration: 'none',
              fontSize: '0.9rem',
              transition: 'background 0.15s',
            }}
            onClick={() => setIsOpen(false)}
            onMouseEnter={(e) => e.target.style.background = 'var(--ifm-color-emphasis-100)'}
            onMouseLeave={(e) => e.target.style.background = 'transparent'}
          >
            🏢 Mi empresa
          </Link>

          <div style={{ borderTop: '1px solid var(--ifm-color-emphasis-200)', marginTop: '0.3rem', paddingTop: '0.3rem' }}>
            <button
              onClick={handleLogout}
              style={{
                display: 'block',
                width: '100%',
                padding: '0.5rem 1rem',
                border: 'none',
                background: 'transparent',
                color: 'var(--ifm-color-danger)',
                fontSize: '0.9rem',
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'background 0.15s',
              }}
              onMouseEnter={(e) => e.target.style.background = 'var(--ifm-color-danger-lightest)'}
              onMouseLeave={(e) => e.target.style.background = 'transparent'}
            >
              🚪 Cerrar sesión
            </button>
          </div>
        </div>
      )}
    </div>
  );
}