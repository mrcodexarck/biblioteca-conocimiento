import React, { useState, useEffect } from 'react';
import Layout from '@theme/Layout';
import { auth, db } from '../firebase';
import { doc, getDoc, updateDoc, setDoc } from 'firebase/firestore';
import { useHistory } from '@docusaurus/router';

export default function Perfil() {
  const [displayName, setDisplayName] = useState('');
  const [role, setRole] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const history = useHistory();

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) {
      history.push('/login');
      return;
    }

    const fetchProfile = async () => {
      try {
        const docRef = doc(db, 'users', user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setDisplayName(data.displayName || user.email?.split('@')[0] || 'Usuario');
          setRole(data.role || 'user');
          setIsAdmin(data.role === 'admin');
        } else {
          // Crear documento por defecto
          const defaultName = user.email?.split('@')[0] || 'Usuario';
          setDisplayName(defaultName);
          setRole('user');
          setIsAdmin(false);
          await setDoc(docRef, {
            displayName: defaultName,
            role: 'user',
          });
        }
      } catch (error) {
        console.error(error);
        setMessage('Error al cargar perfil');
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, [history]);

  const handleSave = async () => {
    const user = auth.currentUser;
    if (!user) return;
    setSaving(true);
    setMessage('');
    try {
      const docRef = doc(db, 'users', user.uid);
      await updateDoc(docRef, {
        displayName: displayName.trim() || 'Usuario',
        role: role,
        updatedAt: new Date(),
      });
      setMessage('✅ Perfil actualizado correctamente');
      setTimeout(() => window.location.reload(), 1000);
    } catch (error) {
      console.error(error);
      setMessage('❌ Error al guardar');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Layout title="Perfil">
        <div className="container margin-vert--xl"><p>Cargando perfil...</p></div>
      </Layout>
    );
  }

  return (
    <Layout title="Perfil de usuario">
      <div className="container margin-vert--xl">
        <h1>⚙️ Configuración de usuario</h1>
        <div className="card">
          <div className="card__body">
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', fontWeight: 'bold' }}>Nombre de usuario</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Tu nombre"
                style={{ width: '100%', padding: '0.5rem', border: '1px solid #ccc', borderRadius: '8px' }}
              />
              <small style={{ color: 'var(--site-muted)' }}>Este nombre aparecerá en tus sugerencias y mensajes.</small>
            </div>

            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', fontWeight: 'bold' }}>Rol</label>
              {isAdmin ? (
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  style={{ width: '100%', padding: '0.5rem', border: '1px solid #ccc', borderRadius: '8px' }}
                >
                  <option value="user">Usuario</option>
                  <option value="admin">Administrador</option>
                </select>
              ) : (
                <input type="text" value="Usuario" disabled style={{ width: '100%', padding: '0.5rem' }} />
              )}
              <small style={{ color: 'var(--site-muted)' }}>
                {isAdmin ? 'Puedes cambiar tu rol.' : 'Solo los administradores pueden cambiar roles.'}
              </small>
            </div>

            {message && <div className="alert alert--info" style={{ marginBottom: '1rem' }}>{message}</div>}

            <button className="button button--primary" onClick={handleSave} disabled={saving}>
              {saving ? 'Guardando...' : 'Guardar cambios'}
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
}